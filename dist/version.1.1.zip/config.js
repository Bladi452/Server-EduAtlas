"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.config = void 0;
var config = {
  host: "localhost",
  user: "tecnodi1_Global",
  password: 'X#_2Q4XXYlO1',
  database: "tecnodi1_Eduatlas"
};
exports.config = config;