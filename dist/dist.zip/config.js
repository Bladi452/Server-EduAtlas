"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.config = void 0;
var config = {
  host: '198.38.88.146',
  user: 'tecnodi1_TecnoDiaz',
  password: 'tecnodiazoficial4523',
  database: 'tecnodi1_Eduatlas-new'
};
exports.config = config;